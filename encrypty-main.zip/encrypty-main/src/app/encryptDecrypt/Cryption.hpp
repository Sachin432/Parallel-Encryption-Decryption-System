#ifndef CRYPTION_HPP
#define CRYPTION_HPP

#include <string>

int executeCryption(const std::string& taskData);

#endif